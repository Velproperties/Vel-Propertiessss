// Mobile menu
const btn = document.querySelector('.menu-btn');
const list = document.querySelector('nav ul');
btn.addEventListener('click', () => list.classList.toggle('open'));
list.querySelectorAll('a').forEach(a => a.addEventListener('click', () => list.classList.remove('open')));

// Property filter
const filterBtns = document.querySelectorAll('.filters button');
const cards = document.querySelectorAll('.card');
filterBtns.forEach(b => b.addEventListener('click', () => {
  filterBtns.forEach(x => x.classList.remove('active'));
  b.classList.add('active');
  const f = b.dataset.filter;
  cards.forEach(c => { c.style.display = (f === 'all' || c.dataset.type === f) ? '' : 'none'; });
}));

// Contact form -> opens the visitor's email app (no backend needed on GitHub Pages)
document.getElementById('enquiry').addEventListener('submit', e => {
  e.preventDefault();
  const d = new FormData(e.target);
  const body = `Name: ${d.get('name')}%0D%0APhone: ${d.get('phone')}%0D%0AInterest: ${d.get('interest')}%0D%0A%0D%0A${encodeURIComponent(d.get('message') || '')}`;
  window.location.href = `mailto:info@velproperties.example?subject=Enquiry from website&body=${body}`;
});
document.getElementById('year').textContent = new Date().getFullYear();
