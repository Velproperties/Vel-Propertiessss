# Vel Properties: Portfolio Website

Static portfolio site for **Vel Properties** (real estate), with an original logo.

## Files
- `index.html`: the page (projects, services, about, contact)
- `styles.css`: styling (colours are CSS variables at the top)
- `script.js`: menu, property filter, enquiry form
- `logo.svg` / `favicon.svg`: logo (a "V" roof holding a vel spearhead)

## Publish on GitHub Pages
1. Create a new repo on GitHub, e.g. `vel-properties`.
2. Upload all files to the repo root (or run `git init`, `git add .`, `git commit -m "Initial site"`, `git remote add origin <repo-url>`, `git push -u origin main`).
3. Go to **Settings, Pages**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
4. After a minute the site is live at `https://<your-username>.github.io/vel-properties/`.

## Customise for the client
- Replace the sample projects in `index.html` with real ones (use `<img src="images/xyz.jpg">` instead of the drawn thumbnails).
- Update phone, email and address in the Contact section and in `script.js`.
- Change brand colours in `:root` in `styles.css`.
